"""add_performance_indexes

Revision ID: c0bd82e0d54a
Revises: dfd6e33eec5e
Create Date: 2025-09-06 21:20:39.457502

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'c0bd82e0d54a'
down_revision = 'dfd6e33eec5e'
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
