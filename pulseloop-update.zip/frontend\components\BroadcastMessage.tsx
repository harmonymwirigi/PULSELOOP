import React, { useState, useEffect } from 'react';
import { BroadcastMessage } from '../types';
import { getActiveBroadcastMessage } from '../services/mockApi';

const BroadcastMessageComponent: React.FC = () => {
    const [broadcastMessage, setBroadcastMessage] = useState<BroadcastMessage | null>(null);
    const [loading, setLoading] = useState(true);
    const [isVisible, setIsVisible] = useState(true);

    useEffect(() => {
        const fetchBroadcastMessage = async () => {
            try {
                console.log('Fetching broadcast message...');
                const response = await getActiveBroadcastMessage();
                console.log('Broadcast message response:', response);
                setBroadcastMessage(response.message);
            } catch (error) {
                console.error('Failed to fetch broadcast message:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchBroadcastMessage();
    }, []);

    console.log('BroadcastMessage render:', { loading, broadcastMessage, isVisible });
    
    if (loading) {
        return <div className="bg-gray-100 py-2 px-4 text-center text-sm text-gray-600">Loading broadcast message...</div>;
    }
    
    if (!broadcastMessage) {
        return null;
    }
    
    if (!isVisible) {
        return null;
    }

    return (
        <div className="bg-gradient-to-r from-indigo-600 to-cyan-600 text-white py-4 px-4 relative overflow-hidden">
            {/* Background Pattern */}
            <div className="absolute inset-0 opacity-10">
                <div className="absolute inset-0" style={{
                    backgroundImage: `radial-gradient(circle at 25% 25%, #ffffff 0%, transparent 50%), 
                                     radial-gradient(circle at 75% 75%, #ffffff 0%, transparent 50%)`,
                    backgroundSize: '100px 100px, 80px 80px'
                }}></div>
            </div>
            
            <div className="container mx-auto relative z-10">
                <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                        {/* Icon */}
                        <div className="flex-shrink-0">
                            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z" />
                                </svg>
                            </div>
                        </div>
                        
                        {/* Message Content */}
                        <div className="flex-1">
                            <h3 className="text-lg font-bold mb-1">{broadcastMessage.title}</h3>
                            <p className="text-indigo-100 text-sm leading-relaxed">{broadcastMessage.message}</p>
                        </div>
                    </div>
                    
                    {/* Close Button */}
                    <button
                        onClick={() => setIsVisible(false)}
                        className="flex-shrink-0 ml-4 p-2 text-white/80 hover:text-white hover:bg-white/20 rounded-full transition-all duration-200"
                        title="Close message"
                    >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </div>
            </div>
        </div>
    );
};

export default BroadcastMessageComponent;
